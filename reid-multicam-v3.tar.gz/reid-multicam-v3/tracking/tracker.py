"""
tracking/tracker.py
───────────────────
ByteTrack-inspired two-stage tracker and a legacy IoU-only tracker.

FIX 3 (from v2): double-increment bug removed.

BUG in v2:
    # Step A — move unmatched active tracks to lost pool:
    t.missing += 1          ← increment #1

    # Step B — immediately after, iterate ALL lost tracks:
    for t in self._lost:
        t.missing += 1      ← increment #2 for tracks JUST moved to lost

Effect:
    A track entering the lost pool gets missing=2 after its FIRST missed
    frame.  With max_missing=30, effective lifetime was only 15 frames of
    occlusion.  This prematurely killed tracks, inflating the ID-switch
    counter.

FIX:
    Only increment missing for tracks that were ALREADY in the lost pool
    before this frame.  Tracks newly moved to lost get missing=1 from
    Step A only.

ALSO FIXED (from v2): removed gid_fn parameter from update().
    In v2, gid_fn was passed but only called with None, producing
    placeholder global IDs immediately overwritten by ReIDPipeline.
    Global ID assignment belongs entirely to ReIDPipeline — not the tracker.
"""

from typing import Dict, List, Set, Tuple

import numpy as np
from scipy.optimize import linear_sum_assignment

from config.settings import SystemConfig
from detection.detector import Detection
from tracking.kalman import kf_to_bbox, make_kalman
from tracking.tracklet import Tracklet


# ──────────────────────────────────────────────────────────────────────────────
#  Matching utilities
# ──────────────────────────────────────────────────────────────────────────────

def iou_matrix(tracks: List[Tracklet],
               dets: List[Detection]) -> np.ndarray:
    """
    Compute an (N_tracks × N_dets) cost matrix where cost = 1 - IoU.
    """
    if not tracks or not dets:
        return np.zeros((len(tracks), len(dets)), dtype=np.float32)

    cost = np.ones((len(tracks), len(dets)), dtype=np.float32)
    for i, t in enumerate(tracks):
        ax1, ay1, ax2, ay2 = t.bbox
        for j, d in enumerate(dets):
            ix1 = max(ax1, d.x1)
            iy1 = max(ay1, d.y1)
            ix2 = min(ax2, d.x2)
            iy2 = min(ay2, d.y2)
            inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
            union = ((ax2 - ax1) * (ay2 - ay1)
                     + (d.x2 - d.x1) * (d.y2 - d.y1)
                     - inter)
            cost[i, j] = 1.0 - inter / (union + 1e-6)
    return cost


def linear_assignment(
    cost: np.ndarray, thresh: float
) -> Tuple[List[Tuple[int, int]], List[int], List[int]]:
    """
    Hungarian assignment filtered by a cost threshold.

    Returns:
        matched:    list of (track_idx, det_idx) pairs with cost < thresh
        unmatched_tracks: track indices with no acceptable match
        unmatched_dets:   detection indices with no acceptable match
    """
    if cost.size == 0:
        return [], list(range(cost.shape[0])), list(range(cost.shape[1]))

    row_ind, col_ind = linear_sum_assignment(cost)

    matched: List[Tuple[int, int]] = []
    matched_r: Set[int] = set()
    matched_c: Set[int] = set()

    for r, c in zip(row_ind, col_ind):
        if cost[r, c] < thresh:
            matched.append((r, c))
            matched_r.add(r)
            matched_c.add(c)

    unm_r = [i for i in range(cost.shape[0]) if i not in matched_r]
    unm_c = [j for j in range(cost.shape[1]) if j not in matched_c]
    return matched, unm_r, unm_c


# ──────────────────────────────────────────────────────────────────────────────
#  ByteTracker
# ──────────────────────────────────────────────────────────────────────────────

class ByteTracker:
    """
    ByteTrack-inspired two-stage IoU tracker with Kalman motion model.

    Reference: Zhang et al., "ByteTrack: Multi-Object Tracking by
               Associating Every Detection Box", ECCV 2022.

    Deviations from the paper (interview-ready):
      - Appearance features not used inside the tracker (handled by ReIDPipeline).
      - State space matches SORT/ByteTrack [x, y, a, h] (FIX 4).
      - No explicit track birth confirmation; birth on first detection.

    Three-stage association:
      Stage 1: active tracks   ↔ high-confidence detections
      Stage 2: remaining active ↔ low-confidence detections
      Stage 3: lost tracks     ↔ remaining high-confidence detections
    """

    def __init__(self, cam_id: str, cfg: SystemConfig) -> None:
        self.cam_id      = cam_id
        self.high_thr    = cfg.high_conf_thr
        self.low_thr     = cfg.low_conf_thr
        self.iou_thr     = 1.0 - cfg.iou_threshold   # convert to 1-IoU cost space
        self.max_missing = cfg.max_missing

        self._active:  Dict[int, Tracklet] = {}
        self._lost:    Dict[int, Tracklet] = {}
        self._next_id: int = 1

    def update(
        self, dets: List[Detection], frame_idx: int
    ) -> Dict[int, Tracklet]:
        """
        Run one tracking step.

        Returns:
            dict of active tracklets: local_id → Tracklet.
            Global ID assignment is NOT done here — that belongs to ReIDPipeline.
        """
        # ── Kalman predict all tracks ──────────────────────────────────────
        for t in {**self._active, **self._lost}.values():
            if t.kf is not None:
                t.kf.predict()
                t.bbox = kf_to_bbox(t.kf)

        high_dets = [d for d in dets if d.conf >= self.high_thr]
        low_dets  = [d for d in dets if self.low_thr <= d.conf < self.high_thr]

        # ── Stage 1: active tracks vs high-conf detections ────────────────
        active_list = list(self._active.values())
        cost1       = iou_matrix(active_list, high_dets)
        matched1, unm_t1, unm_d1 = linear_assignment(cost1, self.iou_thr)

        for ti, di in matched1:
            self._update_track(active_list[ti], high_dets[di], frame_idx)

        # ── Stage 2: remaining active vs low-conf detections ──────────────
        remain_active = [active_list[i] for i in unm_t1]
        cost2         = iou_matrix(remain_active, low_dets)
        matched2, unm_t2, _ = linear_assignment(cost2, self.iou_thr)

        for ti, di in matched2:
            self._update_track(remain_active[ti], low_dets[di], frame_idx)

        # ── Stage 3: lost tracks vs unmatched high-conf detections ─────────
        lost_list = list(self._lost.values())
        unm_highs = [high_dets[j] for j in unm_d1]
        cost3     = iou_matrix(lost_list, unm_highs)
        matched3, _, unm_d3 = linear_assignment(cost3, self.iou_thr)

        for ti, di in matched3:
            t = lost_list[ti]
            self._update_track(t, unm_highs[di], frame_idx)
            self._active[t.local_id] = t
            del self._lost[t.local_id]

        # ── Move still-unmatched active tracks → lost pool ─────────────────
        # FIX 3: record IDs being moved NOW before sweeping the lost pool.
        newly_lost_ids: Set[int] = set()
        unmatched_active = [
            remain_active[i] for i in unm_t2
            if remain_active[i].local_id in self._active
        ]
        for t in unmatched_active:
            t.missing += 1        # increment #1 — the only one this frame
            t.state    = "lost"
            self._lost[t.local_id] = t
            newly_lost_ids.add(t.local_id)
            del self._active[t.local_id]

        # ── Increment missing for tracks already in the lost pool ──────────
        # FIX 3: skip newly_lost_ids to prevent double-increment.
        for lid in list(self._lost.keys()):
            if lid in newly_lost_ids:
                continue        # already incremented above
            t = self._lost[lid]
            t.missing += 1
            if t.missing > self.max_missing:
                t.state = "removed"
                del self._lost[lid]

        # ── Birth new tracklets for still-unmatched high-conf detections ───
        for j in unm_d3:
            det = unm_highs[j]
            lid = self._next_id
            self._next_id += 1
            kf  = make_kalman(det.bbox)
            t   = Tracklet(
                local_id=lid,
                global_id=-1,           # -1 = unassigned; ReIDPipeline sets GID
                bbox=det.bbox,
                cam_id=self.cam_id,
                frame_first=frame_idx,
                frame_last=frame_idx,
                kf=kf,
            )
            t.trajectory.append(t.center)
            self._active[lid] = t

        return dict(self._active)

    def _update_track(
        self, t: Tracklet, det: Detection, frame_idx: int
    ) -> None:
        """Apply a matched detection to update track state."""
        if t.kf is not None:
            x1, y1, x2, y2 = det.bbox
            w = float(x2 - x1)
            h = float(y2 - y1)
            a = w / (h + 1e-6)
            t.kf.update(np.array([[float(x1)], [float(y1)], [a], [h]]))
            t.bbox = kf_to_bbox(t.kf)
        else:
            t.bbox = det.bbox

        t.missing    = 0
        t.state      = "active"
        t.frame_last = frame_idx
        t.trajectory.append(t.center)


# ──────────────────────────────────────────────────────────────────────────────
#  IoUTracker  (legacy — kept for ablation comparison)
# ──────────────────────────────────────────────────────────────────────────────

class IoUTracker:
    """
    Simple IoU-only tracker without Kalman filtering or two-stage association.
    Kept for ablation study to isolate the contribution of ByteTrack/Kalman.
    """

    def __init__(self, cam_id: str, cfg: SystemConfig) -> None:
        self.cam_id      = cam_id
        self.iou_thr     = cfg.iou_threshold
        self.max_missing = cfg.max_missing
        self._tracks:  Dict[int, Tracklet] = {}
        self._next_id: int = 1

    def update(
        self, dets: List[Detection], frame_idx: int
    ) -> Dict[int, Tracklet]:
        if not dets:
            for t in self._tracks.values():
                t.missing += 1
            self._tracks = {
                lid: t for lid, t in self._tracks.items()
                if t.missing <= self.max_missing
            }
            return self._tracks

        active = [t for t in self._tracks.values() if t.missing == 0]
        cost   = iou_matrix(active, dets)
        matched, _, unm_d = linear_assignment(cost, 1.0 - self.iou_thr)

        matched_lids: Set[int] = set()
        for ti, di in matched:
            t = active[ti]
            t.bbox       = dets[di].bbox
            t.missing    = 0
            t.frame_last = frame_idx
            t.trajectory.append(t.center)
            matched_lids.add(t.local_id)

        for t in active:
            if t.local_id not in matched_lids:
                t.missing += 1

        for j in unm_d:
            lid = self._next_id
            self._next_id += 1
            t   = Tracklet(
                local_id=lid,
                global_id=-1,
                bbox=dets[j].bbox,
                cam_id=self.cam_id,
                frame_first=frame_idx,
                frame_last=frame_idx,
            )
            t.trajectory.append(t.center)
            self._tracks[lid] = t

        self._tracks = {
            lid: t for lid, t in self._tracks.items()
            if t.missing <= self.max_missing
        }
        return self._tracks

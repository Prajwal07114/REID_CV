"""
tracking/tracklet.py
────────────────────
Tracklet dataclass — the fundamental unit of tracked state per object.

Each Tracklet holds:
  - Identity (local per-camera ID, global cross-camera ID)
  - Bounding box (updated each frame by the tracker)
  - Kalman filter state
  - Embedding buffer (for stable ReID via mean embedding)
  - Trajectory deque (for visualisation)
  - Lifecycle metadata (frame_first/last, missing count, state)
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Optional, Tuple

import numpy as np


@dataclass
class Tracklet:
    """
    Represents one tracked object across frames within a single camera.

    Attributes:
        local_id:    Camera-local integer ID assigned by the tracker.
        global_id:   Cross-camera identity assigned by ReIDPipeline.
                     -1 means "not yet assigned".
        bbox:        Current bounding box (x1, y1, x2, y2).
        cam_id:      String identifier of the originating camera.
        frame_first: Frame index when this tracklet was born.
        frame_last:  Frame index of the most recent match.
        missing:     How many consecutive frames this track has had no detection.
        state:       One of "active", "lost", "removed".
        emb_buffer:  Circular buffer of recent L2-normalised embeddings.
        trajectory:  Circular buffer of recent centre-point coordinates.
        kf:          Kalman filter instance (None for IoUTracker).
    """

    local_id:    int
    global_id:   int
    bbox:        Tuple[int, int, int, int]
    cam_id:      str
    frame_first: int
    frame_last:  int
    missing:     int = 0
    state:       str = "active"

    emb_buffer:  deque = field(
        default_factory=lambda: deque(maxlen=8))
    trajectory:  deque = field(
        default_factory=lambda: deque(maxlen=100))

    # repr=False keeps dataclass __repr__ readable
    kf: Optional[Any] = field(default=None, repr=False)

    # ── Derived properties ────────────────────────────────────────────────

    @property
    def center(self) -> Tuple[int, int]:
        x1, y1, x2, y2 = self.bbox
        return (x1 + x2) // 2, (y1 + y2) // 2

    @property
    def dwell_frames(self) -> int:
        """Number of frames this tracklet has been alive."""
        return max(0, self.frame_last - self.frame_first)

    @property
    def mean_embedding(self) -> Optional[np.ndarray]:
        """
        L2-normalised mean of all embeddings in the buffer.
        Returns None if the buffer is empty.
        """
        if not self.emb_buffer:
            return None
        stack = np.stack(list(self.emb_buffer), axis=0)
        mean  = stack.mean(axis=0)
        norm  = np.linalg.norm(mean)
        return (mean / (norm + 1e-8)).astype(np.float32)

    # ── Mutation helpers ──────────────────────────────────────────────────

    def add_embedding(self, emb: np.ndarray) -> None:
        """Append an embedding to the circular buffer (deque handles maxlen)."""
        if emb is not None:
            self.emb_buffer.append(emb)

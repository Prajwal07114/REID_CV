"""
tracking/kalman.py
──────────────────
Constant-velocity Kalman filter for bounding-box tracking.

FIX 4 (from v2): state space corrected to [x, y, a, h] — matching the
SORT / ByteTrack standard — replacing the previous [cx, cy, w, h, ...] form.

WHY [x, y, a, h] INSTEAD OF [cx, cy, w, h]:
────────────────────────────────────────────
  Reason 1 — Covariance stability:
    Width (w) varies enormously with distance and camera angle — a person
    2 m away has w≈40 px, at 5 m w≈15 px.  The process noise (Q) and
    measurement noise (R) must be tuned per-scale if you use raw width.
    Aspect ratio is approximately SCALE-INVARIANT: a standing adult is
    always roughly 0.4–0.6 wide/tall regardless of distance.  This allows
    fixed, well-conditioned Q/R matrices.

  Reason 2 — Filter conditioning:
    If w and h have very different magnitudes (e.g. w=30, h=150), the
    off-diagonal covariance terms become poorly conditioned, leading to
    numerically unstable predictions.  Using a = w/h keeps all state
    dimensions in a similar magnitude range.

  Reason 3 — Faithfulness to SORT/ByteTrack:
    Both SORT (Bewley 2016) and ByteTrack (Zhang 2022) use [x, y, a, h].
    Claiming "ByteTrack-style Kalman" with a different state space is
    technically misleading.

State vector:       [x, y, a, h, vx, vy, va, vh]
                     ─────────────  ──────────────
                     position       velocity
  x, y  = top-left corner pixel coordinates
  a     = aspect ratio (width / height)
  h     = bounding-box height in pixels
  v*    = respective velocities (constant-velocity assumption)

Measurement vector: [x, y, a, h]  (direct observation of position state)
"""

from typing import Tuple

import numpy as np
from filterpy.kalman import KalmanFilter


def make_kalman(bbox: Tuple[int, int, int, int]) -> KalmanFilter:
    """
    Initialise a Kalman filter from an (x1, y1, x2, y2) bounding box.

    Returns a KalmanFilter whose state is [x, y, a, h, vx, vy, va, vh].
    Q/R/P values follow standard SORT tuning.
    """
    kf = KalmanFilter(dim_x=8, dim_z=4)

    # Transition matrix — constant-velocity model: x_{t+1} = x_t + vx_t
    kf.F = np.eye(8, dtype=np.float32)
    for i in range(4):
        kf.F[i, i + 4] = 1.0

    # Measurement matrix — we observe the position part directly
    kf.H = np.eye(4, 8, dtype=np.float32)

    # Noise matrices — standard SORT values
    kf.R[2:, 2:] *= 10.0      # lower confidence in aspect/height measurement
    kf.P[4:, 4:] *= 1000.0    # high uncertainty in initial velocity
    kf.P         *= 10.0
    kf.Q[4:, 4:] *= 0.01      # small process noise on velocity

    # Initialise state from the given bounding box
    x1, y1, x2, y2 = bbox
    w = float(x2 - x1)
    h = float(y2 - y1)
    a = w / (h + 1e-6)        # aspect ratio — scale-invariant
    kf.x[:4] = np.array([[float(x1)], [float(y1)], [a], [h]])

    return kf


def kf_to_bbox(kf: KalmanFilter) -> Tuple[int, int, int, int]:
    """
    Convert Kalman state [x, y, a, h] back to (x1, y1, x2, y2) integers.
    """
    x, y, a, h = kf.x[:4, 0]
    w  = a * h
    return int(x), int(y), int(x + w), int(y + h)

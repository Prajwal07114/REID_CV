"""
visualization/hud.py
────────────────────
Drawing utilities, heatmap accumulation, and CameraProcessor.

CameraProcessor owns:
  - OpenCV VideoCapture + VideoWriter
  - Per-camera tracker instance
  - ReIDPipeline reference (shared across cameras)
  - Entry/exit counter
  - Heatmap accumulator
  - ID-switch counter

Detection is done OUTSIDE CameraProcessor via batched calls in main.py.
CameraProcessor.step() receives pre-computed detections.
"""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np

from config.settings    import SystemConfig
from detection.detector import Detection
from reid.pipeline      import ReIDPipeline
from tracking.tracker   import ByteTracker, IoUTracker
from tracking.tracklet  import Tracklet

log = logging.getLogger("ReID.Vis")


# ──────────────────────────────────────────────────────────────────────────────
#  Colour palette
# ──────────────────────────────────────────────────────────────────────────────

_PALETTE = [
    (  0, 230, 100), (  0, 180, 255), (230, 120,   0),
    (200,   0, 200), (  0, 220, 220), (255, 160,   0),
    (100, 255,   0), (  0, 100, 255), (255,  60, 120),
    ( 60, 200, 180), (255, 200,  60), (180,  60, 255),
]
C_TEXT_BG = (  0,   0,   0)
C_HUD_ACC = ( 20, 220,  80)
C_ENTRY   = (  0, 255, 100)
C_EXIT    = (  0,  80, 255)
C_DIM     = (100, 100, 100)
C_LABEL   = (220, 255,  80)


def gid_color(gid: int) -> Tuple[int, int, int]:
    return _PALETTE[(gid - 1) % len(_PALETTE)]


# ──────────────────────────────────────────────────────────────────────────────
#  Heatmap
# ──────────────────────────────────────────────────────────────────────────────

def accumulate_heatmap(
    accum: np.ndarray, tracks: Dict[int, Tracklet]
) -> None:
    """Splat a soft Gaussian blob at each active tracklet's centre."""
    for t in tracks.values():
        if t.missing == 0:
            cx, cy = t.center
            H, W   = accum.shape
            if 0 <= cy < H and 0 <= cx < W:
                cv2.circle(accum, (cx, cy), 20, 1.0, -1)


def render_heatmap(
    accum: np.ndarray, frame: np.ndarray, alpha: float = 0.40
) -> np.ndarray:
    """Overlay a log-normalised TURBO colourmap heatmap on the frame."""
    if accum.max() < 1e-6:
        return frame
    norm  = np.log1p(accum)
    norm  = (norm / (norm.max() + 1e-8) * 255).astype(np.uint8)
    color = cv2.applyColorMap(norm, cv2.COLORMAP_TURBO)
    mask  = (norm > 5).astype(np.uint8)[:, :, None]
    return cv2.addWeighted(frame, 1.0, color * mask, alpha, 0)


# ──────────────────────────────────────────────────────────────────────────────
#  Entry / exit counter
# ──────────────────────────────────────────────────────────────────────────────

class EntryExitCounter:
    def __init__(self) -> None:
        self._seen:   set = set()
        self.entries: int = 0
        self.exits:   int = 0

    def update(self, active_gids: set) -> None:
        self.entries += len(active_gids - self._seen)
        self.exits   += len(self._seen - active_gids)
        self._seen    = set(active_gids)


# ──────────────────────────────────────────────────────────────────────────────
#  Drawing helpers
# ──────────────────────────────────────────────────────────────────────────────

def _put_label(
    img: np.ndarray, text: str,
    pos: Tuple[int, int], color: Tuple
) -> None:
    x, y = pos
    scale, thick = 0.46, 1
    (tw, th), _ = cv2.getTextSize(
        text, cv2.FONT_HERSHEY_SIMPLEX, scale, thick)
    cv2.rectangle(img, (x, y - th - 4), (x + tw + 4, y + 2), C_TEXT_BG, -1)
    cv2.putText(img, text, (x + 2, y - 1),
                cv2.FONT_HERSHEY_SIMPLEX, scale, color, thick, cv2.LINE_AA)


def draw_tracklet(
    frame: np.ndarray, t: Tracklet,
    fps: float, show_traj: bool = True
) -> None:
    """Draw bounding box, label, and trajectory for one tracklet."""
    if t.missing > 0:
        return
    x1, y1, x2, y2 = t.bbox
    col = gid_color(t.global_id) if t.global_id > 0 else C_DIM
    cv2.rectangle(frame, (x1, y1), (x2, y2), col, 2)
    dwell_s = t.dwell_frames / max(fps, 1.0)
    label   = f"GID:{t.global_id:02d} LID:{t.local_id:02d}  {dwell_s:.0f}s"
    _put_label(frame, label, (x1, y1), col)

    if show_traj and len(t.trajectory) >= 2:
        pts = list(t.trajectory)
        for i in range(1, len(pts)):
            alpha = i / len(pts)
            c = tuple(int(v * alpha) for v in col)
            cv2.line(frame, pts[i - 1], pts[i], c, 2, cv2.LINE_AA)
        cv2.circle(frame, pts[-1], 4, col, -1)


def draw_hud(
    frame: np.ndarray,
    cam_id: str,
    n_active: int,
    n_global: int,
    entries: int,
    exits: int,
    fidx: int,
    fps: float,
    model_name: str = "",
    tracker_name: str = "",
) -> None:
    """Draw the heads-up display overlay in the top-left corner."""
    h, w  = frame.shape[:2]
    font  = cv2.FONT_HERSHEY_SIMPLEX
    pw, ph = 300, 130
    ov = frame.copy()
    cv2.rectangle(ov, (6, 6), (6 + pw, 6 + ph), (0, 0, 0), -1)
    cv2.addWeighted(ov, 0.55, frame, 0.45, 0, frame)
    cv2.rectangle(frame, (6, 6), (6 + pw, 6 + ph), C_HUD_ACC, 1)
    lines = [
        (f"● {cam_id.upper()}", C_HUD_ACC),
        (f"TRACKED  : {n_active:>3}", (180, 255, 180)),
        (f"GLOBAL IDs: {n_global:>3}", C_LABEL),
        (f"ENTRIES  : {entries:>3}", C_ENTRY),
        (f"EXITS    : {exits:>3}", C_EXIT),
        (f"ReID:{model_name}  Trk:{tracker_name}", C_DIM),
    ]
    for idx, (txt, col) in enumerate(lines):
        cv2.putText(frame, txt, (14, 26 + idx * 20),
                    font, 0.40, col, 1, cv2.LINE_AA)
    cv2.putText(frame, f"FRAME {fidx:05d}",
                (w - 155, h - 10), font, 0.36, C_DIM, 1, cv2.LINE_AA)


# ──────────────────────────────────────────────────────────────────────────────
#  CameraProcessor
# ──────────────────────────────────────────────────────────────────────────────

class CameraProcessor:
    """
    Per-camera pipeline state.

    Owns the VideoCapture and VideoWriter for one camera.
    Receives pre-computed detections from the batch detector (main.py)
    so that all cameras share a single YOLO forward pass.

    Args:
        cam_id:       String identifier, e.g. "cam1".
        video_path:   Path to the input video file.
        tracker_type: "bytetrack" or "iou".
        reid_pipeline: Shared ReIDPipeline instance.
        cfg:           SystemConfig instance.
    """

    def __init__(
        self,
        cam_id:       str,
        video_path:   str,
        tracker_type: str,
        reid_pipeline: ReIDPipeline,
        cfg:          SystemConfig,
    ) -> None:
        self.cam_id    = cam_id
        self.reid_pipe = reid_pipeline
        self.cfg       = cfg

        self.cap = cv2.VideoCapture(video_path)
        if not self.cap.isOpened():
            raise RuntimeError(f"Cannot open: {video_path}")

        ow    = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        oh    = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.fps   = self.cap.get(cv2.CAP_PROP_FPS) or cfg.dwell_fps_est
        self.total = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
        scale      = cfg.proc_width / ow
        self.pw    = cfg.proc_width
        self.ph    = int(oh * scale)

        self.heatmap_accum = np.zeros((self.ph, self.pw), dtype=np.float32)
        self.counter       = EntryExitCounter()
        self.fidx          = 0
        self.tracker_name  = tracker_type

        self.tracker = (
            ByteTracker(cam_id, cfg)
            if tracker_type.lower() == "bytetrack"
            else IoUTracker(cam_id, cfg)
        )

        out_path    = f"output_{cam_id}.mp4"
        fourcc      = cv2.VideoWriter_fourcc(*"mp4v")
        self.writer = cv2.VideoWriter(out_path, fourcc, self.fps,
                                      (self.pw, self.ph))
        self.out_path    = out_path
        self.id_switches = 0
        self._prev_gids: Dict[int, int] = {}

        log.info(
            f"[{cam_id}] {ow}x{oh} @ {self.fps:.1f}fps  "
            f"{self.total} frames  tracker={tracker_type}"
        )

    def read_frame(self) -> Optional[np.ndarray]:
        """Read and resize one frame. Returns None at end of stream."""
        ret, frame = self.cap.read()
        if not ret:
            return None
        return cv2.resize(frame, (self.pw, self.ph))

    def step(self, frame: np.ndarray, dets: List[Detection]) -> None:
        """
        Process one frame given pre-computed detections.

        Steps:
          1. Tracker update (local IDs)
          2. ReID pipeline update (global IDs)
          3. ID-switch counting
          4. Heatmap accumulation
          5. Visualisation (heatmap overlay + tracklet drawing + HUD)
          6. Write frame to output video
        """
        tracks = self.tracker.update(dets, self.fidx)
        self.reid_pipe.process_frame(frame, tracks, self.fidx, self.cam_id)

        for lid, t in tracks.items():
            prev = self._prev_gids.get(lid)
            if prev is not None and prev != t.global_id and t.global_id != -1:
                self.id_switches += 1
            self._prev_gids[lid] = t.global_id

        accumulate_heatmap(self.heatmap_accum, tracks)
        vis = render_heatmap(
            self.heatmap_accum, frame.copy(), self.cfg.heatmap_alpha)

        for t in tracks.values():
            draw_tracklet(vis, t, self.fps)

        active_gids = {
            t.global_id for t in tracks.values()
            if t.missing == 0 and t.global_id != -1
        }
        self.counter.update(active_gids)

        draw_hud(
            vis,
            cam_id=self.cam_id,
            n_active=len(active_gids),
            n_global=self.reid_pipe.gallery.num_ids,
            entries=self.counter.entries,
            exits=self.counter.exits,
            fidx=self.fidx,
            fps=self.fps,
            model_name=self.cfg.reid_model.upper(),
            tracker_name=self.tracker_name.upper(),
        )
        self.writer.write(vis)
        self.fidx += 1

    def close(self) -> None:
        self.cap.release()
        self.writer.release()

    def summary(self) -> Dict[str, Any]:
        return {
            "cam_id":      self.cam_id,
            "frames":      self.fidx,
            "entries":     self.counter.entries,
            "exits":       self.counter.exits,
            "id_switches": self.id_switches,
            "output":      str(Path(self.out_path).resolve()),
        }

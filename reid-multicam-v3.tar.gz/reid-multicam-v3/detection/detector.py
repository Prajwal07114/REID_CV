"""
detection/detector.py
─────────────────────
YOLOv8-based person detector.

Exposes:
  - Detection  dataclass
  - PersonDetector  with detect() and detect_batch()

FIX (from v2): detect_batch() is now actually called in the main loop
across cameras instead of being dead code.
"""

import logging
from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np
import torch
from ultralytics import YOLO

from config.settings import SystemConfig

log = logging.getLogger("ReID.Detector")


# ──────────────────────────────────────────────────────────────────────────────
#  Data structure
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class Detection:
    x1: int
    y1: int
    x2: int
    y2: int
    conf: float

    @property
    def bbox(self) -> Tuple[int, int, int, int]:
        return self.x1, self.y1, self.x2, self.y2

    @property
    def center(self) -> Tuple[int, int]:
        return (self.x1 + self.x2) // 2, (self.y1 + self.y2) // 2

    def as_xywh(self) -> Tuple[float, float, float, float]:
        return (
            float(self.x1),
            float(self.y1),
            float(self.x2 - self.x1),
            float(self.y2 - self.y1),
        )


# ──────────────────────────────────────────────────────────────────────────────
#  Detector
# ──────────────────────────────────────────────────────────────────────────────

class PersonDetector:
    """
    Wraps a YOLOv8 model to detect persons in single frames or batches.

    Args:
        cfg:    SystemConfig instance (immutable).
        device: torch.device to run inference on.
    """

    def __init__(self, cfg: SystemConfig,
                 device: Optional[torch.device] = None) -> None:
        self.cfg    = cfg
        self.device = device or torch.device(
            "cuda" if torch.cuda.is_available() else "cpu")
        log.info(f"Loading {cfg.det_model} on {self.device}")
        self._model = YOLO(cfg.det_model)

    # ── private helpers ───────────────────────────────────────────────────

    def _parse_results(self, frame: np.ndarray, r) -> List[Detection]:
        """Convert one YOLO result object into a list of Detection instances."""
        H, W = frame.shape[:2]
        dets: List[Detection] = []
        for box in r.boxes:
            if int(box.cls[0]) != self.cfg.person_class:
                continue
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            x1 = max(0, x1)
            y1 = max(0, y1)
            x2 = min(W - 1, x2)
            y2 = min(H - 1, y2)
            if x2 <= x1 or y2 <= y1:
                continue
            dets.append(Detection(x1, y1, x2, y2, float(box.conf[0])))
        return dets

    # ── public API ────────────────────────────────────────────────────────

    def detect(self, frame: np.ndarray) -> List[Detection]:
        """Detect persons in a single frame."""
        results = self._model(
            frame, verbose=False,
            conf=self.cfg.det_conf,
            classes=[self.cfg.person_class],
        )
        return self._parse_results(frame, results[0])

    def detect_batch(self, frames: List[np.ndarray]) -> List[List[Detection]]:
        """
        Batched detection across multiple frames in one model call.
        More efficient than calling detect() per frame.

        Returns a list of detection lists, one per input frame.
        """
        if not frames:
            return []
        results = self._model(
            frames, verbose=False,
            conf=self.cfg.det_conf,
            classes=[self.cfg.person_class],
        )
        return [self._parse_results(f, r) for f, r in zip(frames, results)]

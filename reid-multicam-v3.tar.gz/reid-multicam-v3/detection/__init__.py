from detection.detector import Detection, PersonDetector

__all__ = ["Detection", "PersonDetector"]

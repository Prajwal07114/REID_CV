"""
config/settings.py
──────────────────
Immutable system configuration.

FIX (from v2): SystemConfig is never mutated after construction.
All modules receive a config instance via constructor injection.
No global mutable state.
"""

from dataclasses import dataclass


@dataclass
class SystemConfig:
    # ── Detection ─────────────────────────────────────────────────────────
    proc_width:      int   = 960
    det_conf:        float = 0.40
    det_model:       str   = "yolov8m.pt"
    person_class:    int   = 0

    # ── Tracking ──────────────────────────────────────────────────────────
    tracker_type:    str   = "bytetrack"
    iou_threshold:   float = 0.30
    max_missing:     int   = 30
    high_conf_thr:   float = 0.60
    low_conf_thr:    float = 0.10

    # ── ReID model ────────────────────────────────────────────────────────
    reid_model:      str   = "osnet"
    reid_threshold:  float = 0.55
    emb_dim:         int   = 512
    crop_h:          int   = 256
    crop_w:          int   = 128
    reid_batch_size: int   = 16

    # ── Gallery / matching ────────────────────────────────────────────────
    gallery_max:     int   = 10
    tracklet_buf:    int   = 8
    temporal_window: int   = 300

    # ── Trajectory / visualisation ────────────────────────────────────────
    traj_len:        int   = 100
    heatmap_alpha:   float = 0.40
    dwell_fps_est:   float = 25.0

    # ── Evaluation ────────────────────────────────────────────────────────
    eval_dataset:    str   = "market1501"
    eval_root:       str   = ""

"""
benchmarking/ablation.py
────────────────────────
Ablation study runner: compare tracker × backbone combinations.

Runs the full pipeline for each (model, tracker) combination and
reports FPS, global ID count, ID switches, and entry counts.

Useful for:
  - Quantifying the contribution of each component.
  - Choosing the best trade-off between accuracy and speed.
  - Generating a results table for a report or interview.
"""

import logging
import time
from typing import Any, Dict, List

import torch

from config.settings     import SystemConfig
from detection.detector  import PersonDetector
from reid.gallery        import GalleryManager
from reid.pipeline       import ReIDPipeline, build_engine
from visualization.hud   import CameraProcessor

log = logging.getLogger("ReID.Ablation")


class AblationRunner:
    """
    Grid-search over backbone models × tracker types.

    Args:
        cam_paths: List of video file paths (one per camera).
        models:    List of model names, e.g. ["resnet18", "resnet50", "osnet"].
        trackers:  List of tracker names, e.g. ["iou", "bytetrack"].
        device:    torch.device.
        cfg:       Base SystemConfig (model/tracker fields are overridden per run).
    """

    def __init__(
        self,
        cam_paths: List[str],
        models:    List[str],
        trackers:  List[str],
        device:    torch.device,
        cfg:       SystemConfig,
    ) -> None:
        self.cam_paths = cam_paths
        self.models    = models
        self.trackers  = trackers
        self.device    = device
        self.cfg       = cfg

    def run(self) -> Dict[str, Dict[str, Any]]:
        """
        Run all combinations and print a summary table.

        Returns:
            Dict mapping "{model}+{tracker}" → metrics dict.
        """
        results: Dict[str, Dict[str, Any]] = {}

        for model_name in self.models:
            for tracker_name in self.trackers:
                key = f"{model_name}+{tracker_name}"
                log.info(f"Running ablation: {key}")
                summary = self._run_combination(model_name, tracker_name)
                results[key] = summary

        _print_table(results)
        return results

    def _run_combination(
        self, model_name: str, tracker_name: str
    ) -> Dict[str, Any]:
        # Build a fresh config copy so base config is never mutated
        cfg_copy = SystemConfig(**vars(self.cfg))
        cfg_copy.reid_model   = model_name
        cfg_copy.tracker_type = tracker_name

        engine   = build_engine(model_name, self.device)
        gallery  = GalleryManager(cfg_copy)
        pipeline = ReIDPipeline(engine, gallery)
        detector = PersonDetector(cfg_copy, self.device)

        processors = [
            CameraProcessor(
                cam_id=f"cam{i + 1}",
                video_path=path,
                tracker_type=tracker_name,
                reid_pipeline=pipeline,
                cfg=cfg_copy,
            )
            for i, path in enumerate(self.cam_paths)
        ]

        t0         = time.time()
        max_frames = max(p.total for p in processors)

        for _ in range(max_frames):
            frames = [p.read_frame() for p in processors]
            if not any(f is not None for f in frames):
                break

            valid = [(i, f) for i, f in enumerate(frames) if f is not None]
            batch_dets = detector.detect_batch([f for _, f in valid])
            for (i, frame), dets in zip(valid, batch_dets):
                processors[i].step(frame, dets)

        elapsed = time.time() - t0
        summary = {
            "elapsed_s":   elapsed,
            "fps":         max_frames / max(elapsed, 1e-3),
            "global_ids":  gallery.num_ids,
            "id_switches": sum(p.id_switches for p in processors),
            "entries":     sum(p.counter.entries for p in processors),
        }

        for p in processors:
            p.close()

        return summary


def _print_table(results: Dict[str, Dict[str, Any]]) -> None:
    print(f"\n{'='*72}")
    print("  ABLATION STUDY RESULTS")
    print(f"{'='*72}")
    print(f"  {'Config':<25} {'FPS':>6} {'GIDs':>6} {'ID-SW':>7} {'Entries':>8}")
    print(f"  {'-'*64}")
    for key, v in results.items():
        print(
            f"  {key:<25} {v['fps']:>6.1f} {v['global_ids']:>6} "
            f"{v['id_switches']:>7} {v['entries']:>8}"
        )
    print(f"{'='*72}\n")

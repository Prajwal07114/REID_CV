"""
evaluation/market1501.py
────────────────────────
Correct Market-1501 / DukeMTMC-reID evaluation protocol.

FIX 2 (from v2): correct distractor / junk handling.

BUG in v2:
  pid == -1 images were removed at _load_split() time, so the gallery
  was smaller than the official gallery.  This inflated Rank-1 / mAP
  because "noise" that would push true positives down the ranked list
  was simply absent.  Numbers were NOT comparable to any published result.

CORRECT Market-1501 protocol (Zheng et al., ICCV 2015):
  Gallery: bounding_box_test/ — contains ALL images, INCLUDING distractors.
  Query:   query/

  Image filename format: <pid>_c<camid>s<seq>_<frame>_<det>.jpg
    pid   = person ID  (-1 = distractor / junk)
    camid = camera ID (1–6)

  Distractor (pid == -1) handling:
    - Distractors ARE kept in the gallery  ← v2 removed them (WRONG).
    - Distractors are NOT counted as correct matches.
    - They DO occupy rank positions (they dilute the ranked list).
    - Removing them inflates Rank-1 because you remove noise.

  Same-camera same-ID exclusion:
    For query (q_pid, q_camid), gallery images where
    (g_pid == q_pid AND g_camid == q_camid) are EXCLUDED from evaluation.
    They are removed from the filtered ranked list — not counted as
    positives or negatives.

Reference: Zheng et al., "Scalable Person Re-identification: A Benchmark",
           ICCV 2015.
"""

import logging
from pathlib import Path
from typing import Dict, List, Tuple

import cv2
import numpy as np

from reid.embedding_engine import EmbeddingEngine

log = logging.getLogger("ReID.Eval")


class ReIDEvaluator:
    """
    Implements the official Market-1501 evaluation protocol.

    Results from this class are directly comparable to published
    benchmarks when using a properly trained embedding engine.

    Args:
        engine:       Feature extractor to evaluate.
        dataset_root: Path to the dataset root directory.
        dataset_name: "market1501" or "dukemtmc".
    """

    def __init__(
        self,
        engine: EmbeddingEngine,
        dataset_root: str,
        dataset_name: str = "market1501",
    ) -> None:
        self.engine       = engine
        self.dataset_root = Path(dataset_root)
        self.dataset_name = dataset_name.lower()

    # ── Data loading ───────────────────────────────────────────────────────

    def _load_split(self, split: str) -> List[Tuple[Path, int, int]]:
        """
        Returns list of (img_path, pid, camid).

        FIX 2: For the gallery split, pid == -1 (distractor) images are
        KEPT.  They are excluded only from positive-match counting, not
        from the gallery itself.  For the query split, pid == -1 queries
        are meaningless and skipped.
        """
        if self.dataset_name in ("market1501", "dukemtmc"):
            folder = self.dataset_root / (
                "query" if split == "query" else "bounding_box_test"
            )
        else:
            raise ValueError(f"Unknown dataset: {self.dataset_name!r}")

        data: List[Tuple[Path, int, int]] = []
        for img_path in sorted(folder.glob("*.jpg")):
            name  = img_path.stem
            parts = name.split("_")
            pid   = int(parts[0])
            camid = int(parts[1][1])

            # FIX 2: do NOT skip pid == -1 for gallery split.
            if split == "query" and pid == -1:
                continue

            data.append((img_path, pid, camid))

        return data

    def _extract_all(
        self, data: List[Tuple[Path, int, int]], batch_size: int = 32
    ) -> np.ndarray:
        """Extract embeddings for all images in a split."""
        all_embs = []
        for i in range(0, len(data), batch_size):
            batch = data[i:i + batch_size]
            crops = []
            for img_path, _, _ in batch:
                img = cv2.imread(str(img_path))
                crops.append(
                    img if img is not None
                    else np.zeros((128, 64, 3), dtype=np.uint8)
                )
            embs = self.engine.extract_batch(crops)
            for emb in embs:
                all_embs.append(
                    emb if emb is not None
                    else np.zeros(self.engine.emb_dim, dtype=np.float32)
                )
        return np.stack(all_embs, axis=0)

    # ── Evaluation ─────────────────────────────────────────────────────────

    def run(self, max_rank: int = 10) -> Dict[str, float]:
        """
        Run the full evaluation and return metric dict.

        Returns:
            {mAP, Rank-1, Rank-5, Rank-10, n_query}  (percentages)
        """
        log.info(f"Loading {self.dataset_name} from {self.dataset_root}")
        query_data   = self._load_split("query")
        gallery_data = self._load_split("gallery")

        log.info(
            f"Queries: {len(query_data)}  Gallery: {len(gallery_data)}"
        )
        log.info("Extracting query embeddings...")
        q_embs = self._extract_all(query_data)
        log.info("Extracting gallery embeddings...")
        g_embs = self._extract_all(gallery_data)

        q_pids   = np.array([d[1] for d in query_data])
        q_camids = np.array([d[2] for d in query_data])
        g_pids   = np.array([d[1] for d in gallery_data])
        g_camids = np.array([d[2] for d in gallery_data])

        # Cosine similarity matrix — embeddings are already L2-normalised
        sim_mat = q_embs @ g_embs.T   # shape: (N_q, N_g)

        all_ap   = []
        cmc_hits = np.zeros(max_rank, dtype=np.float32)
        n_valid  = 0

        for q_idx in range(len(q_embs)):
            q_pid   = q_pids[q_idx]
            q_camid = q_camids[q_idx]

            ranked = np.argsort(-sim_mat[q_idx])   # descending similarity

            # FIX 2: build filtered list excluding same-cam-same-id and distractors.
            # These images ARE in the gallery (affecting rank positions) but are
            # not counted as positives or negatives.
            filtered = []
            for g_idx in ranked:
                same_cam_id   = (g_pids[g_idx] == q_pid and
                                 g_camids[g_idx] == q_camid)
                is_distractor = (g_pids[g_idx] == -1)
                if not same_cam_id and not is_distractor:
                    filtered.append(g_idx)

            good_mask = np.array(
                [g_pids[i] == q_pid for i in filtered], dtype=bool
            )

            if good_mask.sum() == 0:
                continue   # no valid positives — skip this query

            n_valid += 1
            all_ap.append(_compute_ap(good_mask))

            first_hit = np.where(good_mask)[0]
            if len(first_hit) > 0:
                hit_rank = first_hit[0]
                if hit_rank < max_rank:
                    cmc_hits[hit_rank:] += 1

        return {
            "mAP":     float(np.mean(all_ap) * 100),
            "Rank-1":  float(cmc_hits[0] / n_valid * 100),
            "Rank-5":  float(cmc_hits[4] / n_valid * 100) if max_rank >= 5  else 0.0,
            "Rank-10": float(cmc_hits[9] / n_valid * 100) if max_rank >= 10 else 0.0,
            "n_query": n_valid,
        }


def _compute_ap(good_mask: np.ndarray) -> float:
    """
    Compute Average Precision for a single query.

    Args:
        good_mask: Boolean array; True at positions of true positives
                   in the filtered ranked gallery list.

    Returns:
        AP as a float in [0, 1].
    """
    num_good = good_mask.sum()
    if num_good == 0:
        return 0.0
    tp           = good_mask.astype(np.float32)
    cumtp        = np.cumsum(tp)
    precision_at = cumtp / (np.arange(len(tp)) + 1.0)
    return float((precision_at * tp).sum() / num_good)

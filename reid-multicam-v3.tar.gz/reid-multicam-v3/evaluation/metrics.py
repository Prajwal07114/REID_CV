"""
evaluation/metrics.py
─────────────────────
Display and persistence helpers for evaluation results.
"""

import json
from pathlib import Path
from typing import Dict


def print_results(results: Dict[str, float], model: str = "") -> None:
    """Pretty-print evaluation results to stdout."""
    print(f"\n{'='*52}")
    print(f"  ReID Evaluation Results  [{model}]")
    print(f"{'='*52}")
    print(f"  mAP     : {results['mAP']:6.2f}%")
    print(f"  Rank-1  : {results['Rank-1']:6.2f}%")
    print(f"  Rank-5  : {results['Rank-5']:6.2f}%")
    print(f"  Rank-10 : {results['Rank-10']:6.2f}%")
    print(f"  Queries : {results['n_query']}")
    print(f"{'='*52}")
    print("  Reference (OSNet-x1_0, Market-1501 pretrained):")
    print("    mAP ~73–75%   Rank-1 ~94%   (torchreid official)")
    print(f"{'='*52}\n")


def save_results(results: Dict[str, float], model: str,
                 out_path: str = "eval_results.json") -> None:
    """Persist results to a JSON file."""
    payload = {"model": model, **results}
    with open(out_path, "w") as f:
        json.dump(payload, f, indent=2)
    print(f"  Evaluation results saved → {Path(out_path).resolve()}")

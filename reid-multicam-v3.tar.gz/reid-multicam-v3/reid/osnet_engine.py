"""
reid/osnet_engine.py
────────────────────
OSNet (Omni-Scale Network) embedding engine.
ReID-pretrained on Market-1501 via torchreid.

FIX 1 (from v2): correct OSNet loading.

OLD code (v2):
    torchreid.models.build_model(name="osnet_x1_0",
                                  num_classes=1000, pretrained=True)

This was wrong for two reasons:

1. OSNet in torchreid is NOT trained on ImageNet with 1000 classes.
   It is trained on ReID datasets (Market-1501: 751 IDs).
   Passing num_classes=1000 causes a classifier head shape mismatch:
   either a runtime error or silently mismatched weights.

2. Even if backbone weights loaded, the embedding space would be wrong.
   ImageNet trains for semantic category separation (cat vs dog).
   ReID trains for IDENTITY separation using metric losses (triplet,
   ArcFace).  An ImageNet backbone's cosine similarity between two
   images of the same person is no better than chance for cross-camera
   matching.

CORRECT approach:
   - num_classes=1 avoids shape mismatch; classifier is replaced anyway.
   - pretrained=True downloads the torchreid Market-1501 checkpoint.
   - Strip the classifier AFTER loading so backbone weights apply fully.
   - Verify embedding shape immediately after loading.

WHY ReID pretraining matters for cosine similarity:
   ReID losses (triplet, circle loss, ArcFace) explicitly optimise the
   embedding space so same-identity pairs have cosine sim > threshold
   and different-identity pairs < threshold.
   ImageNet CE loss does not calibrate for cosine distance — the
   penultimate features are NOT suited for cosine matching.

Reference: Zhou et al., "Omni-Scale Feature Learning for Person
           Re-Identification", ICCV 2019.
"""

import logging
from typing import List, Optional

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as tv_models
import torchvision.transforms as T

from reid.embedding_engine import EmbeddingEngine

log = logging.getLogger("ReID.OSNet")

try:
    import torchreid
    _TORCHREID_OK = True
except ImportError:
    _TORCHREID_OK = False


class OSNetEngine(EmbeddingEngine):
    """
    OSNet-x1_0 with Market-1501 pretrained weights.

    Falls back to a ResNet50 ImageNet backbone if torchreid is not
    installed, with a clear warning about the implications.
    """

    def __init__(self, device: torch.device) -> None:
        self.device   = device
        self._emb_dim = 512

        if not _TORCHREID_OK:
            log.warning(
                "torchreid not available — falling back to ResNet50. "
                "NOTE: ResNet50 here is ImageNet-pretrained, NOT ReID-pretrained. "
                "Cosine similarity threshold must be retuned. "
                "Install torchreid for correct ReID embeddings."
            )
            self._model   = self._build_resnet_fallback(device)
            self._emb_dim = 2048
        else:
            log.info("Loading OSNet-x1_0 with Market-1501 pretrained weights...")
            # FIX 1: num_classes=1 avoids shape mismatch; head is replaced anyway.
            # pretrained=True downloads the Market-1501 checkpoint (NOT ImageNet).
            self._model = torchreid.models.build_model(
                name="osnet_x1_0",
                num_classes=1,
                pretrained=True,
            )
            self._model.classifier = nn.Identity()  # strip classifier head
            self._model = self._model.to(device).eval()
            self._emb_dim = 512
            self._verify_embedding_shape()

        self._transform = T.Compose([
            T.ToPILImage(),
            T.Resize((256, 128)),
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406],
                        std =[0.229, 0.224, 0.225]),
        ])

    def _verify_embedding_shape(self) -> None:
        """Confirm model outputs the correct embedding dimension at startup."""
        dummy = torch.zeros(1, 3, 256, 128, device=self.device)
        with torch.no_grad():
            out = self._model(dummy)
        assert out.shape == (1, 512), (
            f"OSNet embedding shape mismatch: expected (1, 512), got {out.shape}. "
            "Check torchreid version and pretrained weights."
        )
        log.info(f"Embedding shape verified: {out.shape} ✓")

    @staticmethod
    def _build_resnet_fallback(device: torch.device) -> nn.Module:
        """ResNet50 ImageNet fallback when torchreid is unavailable."""
        m = tv_models.resnet50(weights=tv_models.ResNet50_Weights.DEFAULT)
        m.fc = nn.Identity()
        return m.to(device).eval()

    @property
    def emb_dim(self) -> int:
        return self._emb_dim

    def extract_batch(
        self, crops: List[np.ndarray]
    ) -> List[Optional[np.ndarray]]:
        if not crops:
            return []

        tensors:   List[torch.Tensor] = []
        valid_idx: List[int]          = []

        for i, crop in enumerate(crops):
            if crop.size == 0 or crop.shape[0] < 16 or crop.shape[1] < 8:
                continue
            try:
                rgb = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)
                tensors.append(self._transform(rgb))
                valid_idx.append(i)
            except Exception:
                pass

        results: List[Optional[np.ndarray]] = [None] * len(crops)
        if not tensors:
            return results

        batch = torch.stack(tensors).to(self.device)
        with torch.no_grad():
            embs = F.normalize(self._model(batch), p=2, dim=1).cpu().numpy()

        for out_i, orig_i in enumerate(valid_idx):
            results[orig_i] = embs[out_i].astype(np.float32)

        return results

"""
reid/pipeline.py
────────────────
ReIDPipeline — orchestrates embedding extraction and gallery assignment
for all active tracklets in a single camera frame.

Separation of concerns:
  - EmbeddingEngine:  extracts features from image crops (OSNet / ResNet).
  - GalleryManager:   maintains cross-camera identity state.
  - ReIDPipeline:     connects them; called per-frame by CameraProcessor.

Global ID assignment lives here, NOT inside the tracker.
The tracker only assigns local (per-camera) IDs.
"""

import logging
from typing import Dict

import numpy as np

from reid.embedding_engine import EmbeddingEngine
from reid.gallery import GalleryManager
from tracking.tracklet import Tracklet

log = logging.getLogger("ReID.Pipeline")


class ReIDPipeline:
    """
    Per-frame ReID update: extract embeddings → assign / update gallery.

    Args:
        engine:       Feature extractor (OSNetEngine or ResNetEngine).
        gallery:      Cross-camera identity gallery.
        update_every: Run ReID every N frames (reduces compute cost).
    """

    def __init__(
        self,
        engine: EmbeddingEngine,
        gallery: GalleryManager,
        update_every: int = 5,
    ) -> None:
        self.engine       = engine
        self.gallery      = gallery
        self.update_every = update_every

    def process_frame(
        self,
        frame: np.ndarray,
        tracks: Dict[int, Tracklet],
        frame_idx: int,
        cam_id: str,
    ) -> None:
        """
        Extract embeddings for all active (non-missing) tracklets and
        update their global IDs via the gallery.

        Called by CameraProcessor on each processed frame.
        No-op on frames where frame_idx % update_every != 0.
        """
        if frame_idx % self.update_every != 0:
            return

        active = [t for t in tracks.values() if t.missing == 0]
        if not active:
            return

        # Crop all person regions from the frame in one pass
        crops = [
            frame[t.bbox[1]:t.bbox[3], t.bbox[0]:t.bbox[2]]
            for t in active
        ]
        embeddings = self.engine.extract_batch(crops)

        for t, emb in zip(active, embeddings):
            if emb is None:
                continue

            t.add_embedding(emb)
            mean_emb = t.mean_embedding
            if mean_emb is None:
                continue

            new_gid = self.gallery.assign(mean_emb, cam_id, frame_idx)
            if new_gid != t.global_id:
                t.global_id = new_gid
            else:
                # Identity already confirmed — just update the gallery EMA
                self.gallery.update_tracklet(t.global_id, mean_emb,
                                             cam_id, frame_idx)


def build_engine(model_name: str, device) -> EmbeddingEngine:
    """
    Factory function: build an EmbeddingEngine by name.

    Args:
        model_name: one of "osnet", "resnet50", "resnet18".
        device:     torch.device.

    Raises:
        ValueError: if model_name is not recognised.
    """
    from reid.osnet_engine  import OSNetEngine
    from reid.resnet_engine import ResNetEngine

    model_name = model_name.lower()
    if model_name == "osnet":
        return OSNetEngine(device)
    elif model_name == "resnet18":
        return ResNetEngine("resnet18", device)
    elif model_name in ("resnet50", "resnet"):
        return ResNetEngine("resnet50", device)
    else:
        raise ValueError(
            f"Unknown model: {model_name!r}. Choose: osnet, resnet50, resnet18"
        )

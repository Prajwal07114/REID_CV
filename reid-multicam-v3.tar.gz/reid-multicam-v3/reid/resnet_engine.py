"""
reid/resnet_engine.py
─────────────────────
ResNet-based embedding engine for ablation comparison.

NOTE: This uses ImageNet pretraining — NOT ReID-pretrained.

Suitable for ablation to show the gap between an ImageNet backbone and
a ReID-specific model.  Do NOT compare raw numbers to published ReID
benchmarks without fine-tuning on a ReID dataset first.

WHY THE GAP EXISTS:
  ReID loss functions (triplet loss, ArcFace, circle loss) explicitly
  optimise the embedding space so that same-identity pairs have cosine
  similarity > threshold and different-identity pairs < threshold.

  ImageNet cross-entropy loss does NOT calibrate for cosine distance.
  The penultimate ResNet features cluster by appearance category (shirt
  colour, clothing type) rather than by individual identity.  This is
  exactly wrong for cross-camera ReID, where lighting, viewpoint and
  clothing deformations must be invariant.
"""

import logging
from typing import List, Optional

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as tv_models
import torchvision.transforms as T

from reid.embedding_engine import EmbeddingEngine

log = logging.getLogger("ReID.ResNet")


class ResNetEngine(EmbeddingEngine):
    """
    ResNet backbone (resnet18 or resnet50) with ImageNet pretraining.

    Args:
        variant: "resnet18" (emb_dim=512) or "resnet50" (emb_dim=2048).
        device:  torch.device to run inference on.
    """

    def __init__(
        self,
        variant: str = "resnet50",
        device: Optional[torch.device] = None,
    ) -> None:
        self.device = device or torch.device(
            "cuda" if torch.cuda.is_available() else "cpu"
        )
        log.info(f"Loading {variant} (ImageNet pretrained)...")

        if variant == "resnet18":
            m = tv_models.resnet18(weights=tv_models.ResNet18_Weights.DEFAULT)
            self._emb_dim = 512
        else:
            m = tv_models.resnet50(weights=tv_models.ResNet50_Weights.DEFAULT)
            self._emb_dim = 2048

        m.fc = nn.Identity()
        self._model = m.to(self.device).eval()

        self._transform = T.Compose([
            T.ToPILImage(),
            T.Resize((256, 128)),
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406],
                        std =[0.229, 0.224, 0.225]),
        ])

    @property
    def emb_dim(self) -> int:
        return self._emb_dim

    def extract_batch(
        self, crops: List[np.ndarray]
    ) -> List[Optional[np.ndarray]]:
        if not crops:
            return []

        tensors:   List[torch.Tensor] = []
        valid_idx: List[int]          = []

        for i, crop in enumerate(crops):
            if crop.size == 0 or crop.shape[0] < 16 or crop.shape[1] < 8:
                continue
            try:
                rgb = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)
                tensors.append(self._transform(rgb))
                valid_idx.append(i)
            except Exception:
                pass

        results: List[Optional[np.ndarray]] = [None] * len(crops)
        if not tensors:
            return results

        batch = torch.stack(tensors).to(self.device)
        with torch.no_grad():
            embs = F.normalize(self._model(batch), p=2, dim=1).cpu().numpy()

        for out_i, orig_i in enumerate(valid_idx):
            results[orig_i] = embs[out_i].astype(np.float32)

        return results

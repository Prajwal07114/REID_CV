"""
reid/embedding_engine.py
────────────────────────
Abstract base class for all ReID embedding engines.

All engines must:
  - Accept a batch of BGR numpy crops.
  - Return L2-normalised embeddings as float32 numpy arrays.
  - Return None for invalid/empty crops.
  - Expose an emb_dim property.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Tuple

import numpy as np


class EmbeddingEngine(ABC):
    """
    Interface for a person ReID feature extractor.

    Subclasses: OSNetEngine, ResNetEngine.
    """

    @abstractmethod
    def extract_batch(
        self, crops: List[np.ndarray]
    ) -> List[Optional[np.ndarray]]:
        """
        Extract L2-normalised embeddings for a batch of BGR crops.

        Args:
            crops: list of HxWxC uint8 BGR images.

        Returns:
            list of the same length; each element is either:
              - np.ndarray of shape (emb_dim,) with L2 norm ≈ 1.0, or
              - None if the crop was invalid (too small, empty, etc.).
        """
        ...

    def extract_single(
        self,
        frame: np.ndarray,
        bbox: Tuple[int, int, int, int],
    ) -> Optional[np.ndarray]:
        """
        Convenience wrapper: extract one embedding from a frame + bounding box.
        """
        x1, y1, x2, y2 = bbox
        crop = frame[y1:y2, x1:x2]
        if crop.size == 0 or crop.shape[0] < 16 or crop.shape[1] < 8:
            return None
        results = self.extract_batch([crop])
        return results[0] if results else None

    @property
    @abstractmethod
    def emb_dim(self) -> int:
        """Dimensionality of the output embedding vector."""
        ...

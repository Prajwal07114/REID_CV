"""
reid/gallery.py
───────────────
Cross-camera identity gallery with EMA embedding updates.

FIX (from v2): gallery buffer uses deque(maxlen=) instead of list.pop(0).
  list.pop(0) is O(N); deque.append on a bounded deque is O(1).

FIX (from v2): EMA alpha corrected.
  v2 used alpha=0.9, which weights the OLD embedding 9× more than the
  new one — the gallery barely adapts to appearance changes across cameras.
  0.5 gives equal weight to old and new, allowing reasonable adaptation.

FIX (from v2): removed fake re-ranking fields.
  rerank_k1/k2/lambda were declared in SystemConfig but re-ranking was
  never implemented.  Removed to avoid misleading documentation.
"""

import logging
from collections import defaultdict, deque
from typing import Dict, Optional, Set

import numpy as np

from config.settings import SystemConfig

log = logging.getLogger("ReID.Gallery")


class GalleryManager:
    """
    Maintains a gallery of global identities across all cameras.

    Each global identity (gid) is represented by:
      - A bounded deque of recent L2-normalised embeddings.
      - An EMA (exponential moving average) embedding for fast matching.

    Matching strategy: cosine similarity between a probe embedding and
    all EMA gallery vectors.  If the best match exceeds `threshold`,
    the probe is assigned to that identity.  Otherwise a new identity
    is created.

    Args:
        cfg: SystemConfig instance.
    """

    def __init__(self, cfg: SystemConfig) -> None:
        self.threshold       = cfg.reid_threshold
        self.gallery_max     = cfg.gallery_max
        self.temporal_window = cfg.temporal_window

        # EMA alpha: weight given to the old embedding.
        # 0.5 = equal weight old/new — adapts to appearance changes.
        # Higher alpha → slower adaptation.
        self._ema_alpha = 0.5

        # gid → bounded deque of L2-normalised embeddings
        self._gallery:   Dict[int, deque]            = {}
        # gid → current EMA embedding (for O(1) cosine similarity)
        self._ema:       Dict[int, np.ndarray]        = {}
        # gid → {cam_id: last_seen_frame}
        self._last_seen: Dict[int, Dict[str, int]]    = defaultdict(dict)
        # gid → set of camera IDs this identity has appeared in
        self._cams:      Dict[int, Set[str]]          = defaultdict(set)

        self._next_gid: int = 1

    # ── Public API ─────────────────────────────────────────────────────────

    def assign(
        self,
        embedding: Optional[np.ndarray],
        cam_id: str,
        frame_idx: int,
    ) -> int:
        """
        Assign a probe embedding to the best-matching gallery identity,
        or create a new identity if no match exceeds `threshold`.

        Returns the assigned global ID (gid).
        """
        if embedding is None or not self._gallery:
            return self._new_id(embedding, cam_id, frame_idx)

        best_gid, best_sim = -1, -1.0
        for gid, ema_emb in self._ema.items():
            sim = float(np.dot(embedding, ema_emb))
            if sim > best_sim:
                best_sim, best_gid = sim, gid

        if best_sim >= self.threshold:
            self._update(best_gid, embedding, cam_id, frame_idx)
            return best_gid

        return self._new_id(embedding, cam_id, frame_idx)

    def update_tracklet(
        self,
        gid: int,
        embedding: Optional[np.ndarray],
        cam_id: str,
        frame_idx: int,
    ) -> None:
        """Update the gallery for an already-assigned identity."""
        if embedding is None or gid not in self._gallery:
            return
        self._update(gid, embedding, cam_id, frame_idx)

    @property
    def num_ids(self) -> int:
        """Total number of distinct global identities in the gallery."""
        return len(self._gallery)

    @property
    def gallery(self) -> Dict[int, deque]:
        """Read-only view of the raw gallery deques."""
        return self._gallery

    # ── Private helpers ────────────────────────────────────────────────────

    def _new_id(
        self,
        embedding: Optional[np.ndarray],
        cam_id: str,
        frame_idx: int,
    ) -> int:
        gid = self._next_gid
        self._next_gid += 1
        self._gallery[gid] = deque(maxlen=self.gallery_max)
        if embedding is not None:
            self._gallery[gid].append(embedding)
            self._ema[gid] = embedding.copy()
        self._last_seen[gid][cam_id] = frame_idx
        self._cams[gid].add(cam_id)
        return gid

    def _update(
        self,
        gid: int,
        embedding: np.ndarray,
        cam_id: str,
        frame_idx: int,
    ) -> None:
        self._gallery[gid].append(embedding)  # deque handles maxlen
        if gid in self._ema:
            ema = self._ema_alpha * self._ema[gid] + (1 - self._ema_alpha) * embedding
            self._ema[gid] = ema / (np.linalg.norm(ema) + 1e-8)
        else:
            self._ema[gid] = embedding.copy()
        self._last_seen[gid][cam_id] = frame_idx
        self._cams[gid].add(cam_id)

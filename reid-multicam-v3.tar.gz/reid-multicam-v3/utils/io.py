"""
utils/io.py
───────────
File I/O helpers: session summary persistence and CLI validation.
"""

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List

log = logging.getLogger("ReID.IO")


def validate_video_paths(paths: List[str]) -> bool:
    """Return True if all paths exist; log an error for each missing file."""
    ok = True
    for p in paths:
        if not os.path.exists(p):
            log.error(f"Video not found: '{p}'")
            ok = False
    return ok


def save_session(session: Dict[str, Any],
                 out_path: str = "reid_session.json") -> None:
    """Persist the session summary dict to JSON."""
    with open(out_path, "w") as f:
        json.dump(session, f, indent=2)
    print(f"  Session summary → {Path(out_path).resolve()}")

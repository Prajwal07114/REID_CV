"""
utils/logging_utils.py
───────────────────────
Logging configuration for the ReID system.
"""

import logging


def setup_logging(level: int = logging.INFO) -> None:
    """Configure root logger with a consistent format."""
    logging.basicConfig(
        level=level,
        format="[%(levelname)s] %(message)s",
    )
    # Suppress noisy third-party loggers
    logging.getLogger("ultralytics").setLevel(logging.WARNING)
    logging.getLogger("torch").setLevel(logging.WARNING)

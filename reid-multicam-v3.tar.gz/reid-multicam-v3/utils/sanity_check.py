"""
utils/sanity_check.py
─────────────────────
Embedding engine sanity checks.

Verifies that the engine produces valid, discriminative embeddings:
  1. Shape  — must be (emb_dim,)
  2. Norm   — must be 1.0 (L2-normalised)
  3. Self-similarity — sim(x, x) must equal 1.0
  4. Distinctness    — sim(crop1, crop2) must be < 0.99

A ReID-pretrained model should show clearly higher cosine similarity
for same-identity pairs than different-identity pairs.
This test only validates that the engine is functioning, not calibrated.
"""

import numpy as np

from reid.embedding_engine import EmbeddingEngine


def run_embedding_sanity_check(engine: EmbeddingEngine) -> None:
    """
    Run four deterministic checks on the embedding engine.

    Raises AssertionError on the first failed check.
    """
    print("\n" + "=" * 56)
    print("  Embedding Engine Sanity Check")
    print("=" * 56)

    rng   = np.random.RandomState(42)
    crop1 = (rng.rand(128, 64, 3) * 255).astype(np.uint8)
    crop2 = (rng.rand(128, 64, 3) * 255).astype(np.uint8)

    embs = engine.extract_batch([crop1, crop1, crop2])
    e1a, e1b, e2 = embs[0], embs[1], embs[2]

    assert e1a is not None, "FAIL: engine returned None for a valid crop"

    # 1. Shape
    assert e1a.shape == (engine.emb_dim,), \
        f"FAIL shape: {e1a.shape} != ({engine.emb_dim},)"
    print(f"  [PASS] Shape         : {e1a.shape}")

    # 2. L2 norm
    norm = np.linalg.norm(e1a)
    assert abs(norm - 1.0) < 1e-5, f"FAIL norm: {norm:.6f} (expected 1.0)"
    print(f"  [PASS] L2 norm       : {norm:.6f}")

    # 3. Self-similarity
    self_sim = float(np.dot(e1a, e1b))
    assert abs(self_sim - 1.0) < 1e-5, f"FAIL self-sim: {self_sim:.6f}"
    print(f"  [PASS] Self-sim      : {self_sim:.6f} (expected 1.0)")

    # 4. Distinctness
    cross_sim = float(np.dot(e1a, e2))
    assert cross_sim < 0.99, \
        f"FAIL distinctness: cross-sim={cross_sim:.4f} — embeddings collapsed"
    print(f"  [PASS] Cross-sim     : {cross_sim:.4f} (expected < 0.99)")

    print("  All checks passed.\n")
    print("  NOTE: For a ReID-pretrained model, same-identity pairs should")
    print("  have cosine sim > 0.7, different-identity pairs < 0.4.")
    print("  This test only validates the engine is functioning, not calibrated.")
    print("=" * 56 + "\n")

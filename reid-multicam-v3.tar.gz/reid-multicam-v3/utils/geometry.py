"""
utils/geometry.py
─────────────────
Bounding-box geometry helpers used across modules.
"""

from typing import Tuple


def iou(a: Tuple[int, int, int, int],
        b: Tuple[int, int, int, int]) -> float:
    """
    Compute intersection-over-union for two (x1, y1, x2, y2) boxes.

    Returns a float in [0, 1].
    """
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b

    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)

    inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
    union = ((ax2 - ax1) * (ay2 - ay1)
             + (bx2 - bx1) * (by2 - by1)
             - inter)
    return inter / (union + 1e-6)


def clip_bbox(
    x1: int, y1: int, x2: int, y2: int,
    W: int, H: int
) -> Tuple[int, int, int, int]:
    """Clip a bounding box to image dimensions."""
    return (
        max(0, x1),
        max(0, y1),
        min(W - 1, x2),
        min(H - 1, y2),
    )


def xywh_to_xyxy(
    x: float, y: float, w: float, h: float
) -> Tuple[int, int, int, int]:
    """Convert top-left (x, y, w, h) to (x1, y1, x2, y2) integers."""
    return int(x), int(y), int(x + w), int(y + h)


def xyxy_to_xywh(
    x1: int, y1: int, x2: int, y2: int
) -> Tuple[float, float, float, float]:
    """Convert (x1, y1, x2, y2) to top-left (x, y, w, h) floats."""
    return float(x1), float(y1), float(x2 - x1), float(y2 - y1)
